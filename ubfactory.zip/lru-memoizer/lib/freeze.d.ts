export declare function deepFreeze(o: any): any;
