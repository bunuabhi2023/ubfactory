declare const htmlBlocks: string[];

export = htmlBlocks;
