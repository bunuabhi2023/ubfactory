interface MapType {
    [key: string]: string;
}

declare const entities: MapType;

export = entities;
