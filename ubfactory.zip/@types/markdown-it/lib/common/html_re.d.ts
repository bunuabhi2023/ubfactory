interface HtmlRE {
    HTML_TAG_RE: RegExp;
    HTML_OPEN_CLOSE_TAG_RE: RegExp;
}

declare const htmlRE: HtmlRE;

export = htmlRE;
