# Installation
> `npm install --save @types/send`

# Summary
This package contains type definitions for send (https://github.com/pillarjs/send).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/send.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 16:34:33 GMT
 * Dependencies: [@types/mime](https://npmjs.com/package/@types/mime), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Mike Jerred](https://github.com/MikeJerred), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
