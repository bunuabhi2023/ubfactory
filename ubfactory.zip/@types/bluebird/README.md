# Installation
> `npm install --save @types/bluebird`

# Summary
This package contains type definitions for bluebird (https://github.com/petkaantonov/bluebird).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bluebird.

### Additional Details
 * Last updated: Mon, 28 Nov 2022 17:02:52 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Leonard Hecker](https://github.com/lhecker).
