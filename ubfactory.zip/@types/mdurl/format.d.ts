import { Url } from './';

declare function format(url: Url): string;

export = format;
