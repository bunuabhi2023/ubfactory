declare namespace encode {
    const defaultChars: string;
    const componentChars: string;
}
declare function encode(str: string, exclude?: string, keepEscaped?: boolean): string;

export = encode;
