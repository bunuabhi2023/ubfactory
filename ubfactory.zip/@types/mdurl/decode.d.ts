declare namespace decode {
    const defaultChars: string;
    const componentChars: string;
}
declare function decode(input: string, exclude?: string): string;

export = decode;
