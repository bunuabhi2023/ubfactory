# Installation
> `npm install --save @types/tough-cookie`

# Summary
This package contains type definitions for tough-cookie (https://github.com/salesforce/tough-cookie).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/tough-cookie.

### Additional Details
 * Last updated: Thu, 14 Apr 2022 07:01:24 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Leonard Thieu](https://github.com/leonard-thieu), [LiJinyao](https://github.com/LiJinyao), and [Michael Wei](https://github.com/no2chem).
